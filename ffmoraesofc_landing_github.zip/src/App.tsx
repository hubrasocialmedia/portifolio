import { useEffect } from 'react';
import './App.css';
import logoHubra from './assets/images/LogoHubra.png';

// Importando os componentes da versão anterior
import Navbar from './components/Navbar';
import About from './components/About';
import Services from './components/Services';
import Results from './components/Results';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  // Animação de abertura com a logo
  useEffect(() => {
    const splashScreen = document.createElement('div');
    splashScreen.className = 'splash-screen';
    
    const logoImg = document.createElement('img');
    logoImg.src = logoHubra;
    logoImg.className = 'splash-logo';
    logoImg.alt = 'Hubra';
    
    splashScreen.appendChild(logoImg);
    document.body.appendChild(splashScreen);
    
    // Remover a tela de splash após 2 segundos
    setTimeout(() => {
      splashScreen.style.opacity = '0';
      setTimeout(() => {
        document.body.removeChild(splashScreen);
      }, 500);
    }, 2000);
  }, []);

  return (
    <div className="app">
      {/* Adicionando a barra de navegação */}
      <Navbar />
      
      {/* Mantendo o início como está atualmente */}
      <div id="home" className="hero-section">
        <div className="content">
          <div className="text-content">
            <h1>O nosso negócio é <br/><span className="highlight">Acelerar os seus</span><br/> Resultados.</h1>
            <p>Vamos elaborar o melhor plano de ação para aumentar a sua receita e o seu negócio, no menor tempo possível.</p>
            <a href="https://wa.me/+5533991372932" className="cta-button whatsapp-button">
              <i className="whatsapp-icon"></i>
              Chamar no WhatsApp
            </a>
            
            <div className="stats">
              <div className="stat-item">
                <span className="stat-number">100+</span>
                <span className="stat-label">Clientes</span>
              </div>
              <div className="stat-item">
                <span className="stat-number">50+</span>
                <span className="stat-label">Projetos</span>
              </div>
              <div className="stat-item">
                <span className="stat-number">500k</span>
                <span className="stat-label">Resultados</span>
              </div>
            </div>
          </div>
          
          <div className="visual-content">
            {/* Área do cavalo 3D, elementos flutuantes e estrutura completa removidos conforme solicitado */}
          </div>
        </div>
      </div>
      
      {/* Integrando o restante dos componentes da landing page */}
      <About />
      <Services />
      <Results />
      <Testimonials />
      <FAQ />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;

import { useState, useEffect } from 'react';

const Results = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('resultados');
      if (element) {
        const position = element.getBoundingClientRect();
        if (position.top < window.innerHeight * 0.75) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check on initial load
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section id="resultados" className="py-20 bg-[#0a0a0a]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Left side - Laptop mockup with graph */}
          <div className={`w-full lg:w-1/2 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-10'} transition-all duration-1000`}>
            <div className="relative">
              <div className="relative z-10 rounded-lg overflow-hidden shadow-2xl">
                <div className="bg-[#1a1a1a] p-4 rounded-t-lg flex items-center">
                  <div className="flex space-x-2">
                    <div className="w-3 h-3 rounded-full bg-red-500"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  </div>
                </div>
                <div className="bg-[#0f1a20] p-4">
                  <div className="bg-[#0a0a0a] rounded-lg p-4">
                    <div className="h-64 w-full bg-[#0f1a20] rounded-lg overflow-hidden">
                      {/* Graph visualization */}
                      <div className="h-full w-full flex items-end justify-between px-4 pt-4">
                        <div className="h-[20%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[30%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[25%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[40%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[35%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[60%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[75%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                        <div className="h-[90%] w-6 bg-gradient-to-t from-[#00e5ff] to-[#00e5ff]/50 rounded-t-md"></div>
                      </div>
                    </div>
                    <div className="mt-4 grid grid-cols-2 gap-4">
                      <div className="bg-[#0f1a20] p-3 rounded-lg">
                        <div className="text-[#00e5ff] text-sm">Engajamento</div>
                        <div className="text-white font-bold text-xl">+487%</div>
                      </div>
                      <div className="bg-[#0f1a20] p-3 rounded-lg">
                        <div className="text-[#00e5ff] text-sm">Conversões</div>
                        <div className="text-white font-bold text-xl">+352%</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Decorative elements */}
              <div className="absolute -bottom-6 -right-6 w-24 h-24 bg-gradient-to-br from-[#00e5ff] to-[#4d00e5] rounded-full blur-xl opacity-30"></div>
              <div className="absolute -top-6 -left-6 w-32 h-32 bg-gradient-to-br from-[#4d00e5] to-[#00e5ff] rounded-full blur-xl opacity-20"></div>
            </div>
          </div>
          
          {/* Right side - Content */}
          <div className={`w-full lg:w-1/2 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'} transition-all duration-1000 delay-300`}>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Estrutura completa para <span className="text-[#00e5ff]">resultados reais</span>
            </h2>
            <p className="text-gray-300 mb-8">
              Nossa metodologia comprovada transforma sua presença digital em uma máquina de resultados, com estratégias personalizadas para cada objetivo.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="bg-[#00e5ff]/10 p-3 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00e5ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Tráfego Qualificado</h3>
                  <p className="text-gray-400">Atraímos visitantes realmente interessados no seu produto ou serviço.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-[#00e5ff]/10 p-3 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00e5ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Conteúdo Estratégico</h3>
                  <p className="text-gray-400">Criamos conteúdo que engaja, converte e fortalece sua marca.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="bg-[#00e5ff]/10 p-3 rounded-full">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00e5ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2">Análise de Dados</h3>
                  <p className="text-gray-400">Monitoramento constante para otimizar resultados e maximizar ROI.</p>
                </div>
              </div>
            </div>
            
            <div className="mt-10">
              <a 
                href="#contato" 
                className="bg-[#00e5ff] text-[#0a0a0a] px-6 py-3 rounded-md font-medium hover:bg-[#00c2d8] transition-colors inline-block"
              >
                Quero resultados agora
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Results;

import { useState, useEffect } from 'react';

const Contact = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('contato');
      if (element) {
        const position = element.getBoundingClientRect();
        if (position.top < window.innerHeight * 0.75) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check on initial load
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    // Simulação de envio de formulário
    alert('Mensagem enviada com sucesso! Em breve entraremos em contato.');
    setFormData({
      name: '',
      email: '',
      phone: '',
      message: ''
    });
  };

  return (
    <section id="contato" className="py-20 bg-[#0a0a0a]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row gap-12">
          {/* Left side - Form */}
          <div className={`w-full lg:w-1/2 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} transition-all duration-1000`}>
            <div className="bg-[#0f1a20] p-8 rounded-lg border border-gray-800">
              <h2 className="text-2xl md:text-3xl font-bold mb-6">
                Eleve seu <span className="text-[#00e5ff]">Negócio Agora!</span>
              </h2>
              
              <p className="text-gray-300 mb-8">
                Preencha o formulário abaixo e nossa equipe entrará em contato para uma análise personalizada do seu negócio.
              </p>
              
              <form onSubmit={handleSubmit}>
                <div className="mb-4">
                  <label htmlFor="name" className="block text-gray-300 mb-2">Nome</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full bg-[#0a0a0a] border border-gray-700 rounded-md py-3 px-4 text-white focus:outline-none focus:border-[#00e5ff]"
                    required
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full bg-[#0a0a0a] border border-gray-700 rounded-md py-3 px-4 text-white focus:outline-none focus:border-[#00e5ff]"
                    required
                  />
                </div>
                
                <div className="mb-4">
                  <label htmlFor="phone" className="block text-gray-300 mb-2">Telefone</label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full bg-[#0a0a0a] border border-gray-700 rounded-md py-3 px-4 text-white focus:outline-none focus:border-[#00e5ff]"
                    required
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="message" className="block text-gray-300 mb-2">Mensagem</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    className="w-full bg-[#0a0a0a] border border-gray-700 rounded-md py-3 px-4 text-white focus:outline-none focus:border-[#00e5ff]"
                    required
                  ></textarea>
                </div>
                
                <button
                  type="submit"
                  className="w-full bg-[#00e5ff] text-[#0a0a0a] py-3 px-6 rounded-md font-medium hover:bg-[#00c2d8] transition-colors"
                >
                  Enviar Mensagem
                </button>
              </form>
            </div>
          </div>
          
          {/* Right side - Content */}
          <div className={`w-full lg:w-1/2 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} transition-all duration-1000 delay-300`}>
            <div className="bg-[#0f1a20] p-8 rounded-lg border border-gray-800 mb-8">
              <h3 className="text-xl font-bold mb-4">
                <span className="text-[#00e5ff]">ATENÇÃO!</span>
              </h3>
              
              <p className="text-gray-300 mb-4">
                Analise seu crescimento agora com a <span className="text-[#00e5ff] font-medium">HUBRA</span>!
              </p>
              
              <p className="text-gray-300 mb-6">
                Pronto para elevar seu negócio a um novo nível com a HUBRA? Estamos prontos para transformar sua presença digital e impulsionar seus resultados. Fale conosco para uma análise completa e descubra as possibilidades!
              </p>
              
              <a 
                href="https://wa.me/+5533991372932" 
                className="bg-[#00e5ff] text-[#0a0a0a] px-6 py-3 rounded-md font-medium hover:bg-[#00c2d8] transition-colors inline-block w-full text-center"
              >
                Elevar meu Negócio Agora!
              </a>
            </div>
            
            <div className="bg-[#0f1a20] p-8 rounded-lg border border-gray-800">
              <h3 className="text-xl font-bold mb-6">
                Cancele, <span className="text-[#00e5ff]">quando quiser!</span>
              </h3>
              
              <p className="text-gray-300 mb-6">
                Na HUBRA, não acreditamos em contratos longos e inflexíveis. Trabalhamos com transparência e resultados. Se não estiver satisfeito, pode cancelar a qualquer momento, sem burocracia.
              </p>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#0a0a0a] flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00e5ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                  </svg>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Telefone</div>
                  <div className="text-white font-medium">+5533991372932</div>
                </div>
              </div>
              
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#0a0a0a] flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00e5ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Email</div>
                  <div className="text-white font-medium">contato@hubra.com.br</div>
                </div>
              </div>
              
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-[#0a0a0a] flex items-center justify-center flex-shrink-0">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-[#00e5ff]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div>
                  <div className="text-gray-400 text-sm">Localização</div>
                  <div className="text-white font-medium">Lajinha, MG</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;

import { useState, useEffect } from 'react';
import logoKaroline from '../assets/images/karolinebronze-Logoredonda.png';
import logoStudioAgah from '../assets/images/LogoStudioAgah.png';
import logoCafeteria from '../assets/images/LogoRedonda-CAFETERIA.png';

const Testimonials = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('depoimentos');
      if (element) {
        const position = element.getBoundingClientRect();
        if (position.top < window.innerHeight * 0.75) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check on initial load
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const testimonials = [
    {
      name: "Guilherme P.",
      role: "Cafeteria Vista do Forte",
      content: "A HUBRA transformou completamente nossa presença digital. Em apenas 4 meses, aumentamos nosso engajamento em mais de 400% e convertemos seguidores em clientes fiéis.",
      stars: 5,
      logo: logoCafeteria
    },
    {
      name: "Renata C.",
      role: "Studio Agah",
      content: "Profissionalismo e resultados! Desde que começamos a trabalhar com a HUBRA, nossas redes sociais ganharam vida nova e as conversões aumentaram significativamente.",
      stars: 5,
      logo: logoStudioAgah
    },
    {
      name: "Karoline",
      role: "Bronzeamento",
      content: "Estratégia, criatividade e resultados mensuráveis. A equipe da HUBRA entendeu perfeitamente nosso negócio e desenvolveu uma estratégia digital que superou todas as expectativas.",
      stars: 5,
      logo: logoKaroline
    }
  ];

  return (
    <section id="depoimentos" className="py-20 bg-[#0a0a0a]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            O QUE NOSSOS <span className="text-[#00e5ff]">CLIENTES</span><br />
            ESTÃO FALANDO SOBRE NÓS
          </h2>
          <p className="text-gray-300 max-w-3xl mx-auto">
            Veja como nossos clientes estão transformando seus negócios com nossas estratégias de marketing digital e social media.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div 
              key={index}
              className={`bg-[#0f1a20] p-8 rounded-lg border border-gray-800 ${
                isVisible 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 150}ms`, transitionDuration: '1000ms', transitionProperty: 'all' }}
            >
              <div className="flex items-center mb-4">
                {[...Array(testimonial.stars)].map((_, i) => (
                  <svg key={i} xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-yellow-400" viewBox="0 0 20 20" fill="currentColor">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>
              
              <p className="text-gray-300 mb-6 italic">"{testimonial.content}"</p>
              
              <div className="flex items-center">
                <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                  <img src={testimonial.logo} alt={testimonial.name} className="w-full h-full object-cover" />
                </div>
                <div className="ml-3">
                  <div className="font-bold">{testimonial.name}</div>
                  <div className="text-gray-400 text-sm">{testimonial.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-16 text-center ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} transition-all duration-500 delay-500`}>
          <a 
            href="https://wa.me/+5533991372932" 
            className="bg-[#25D366] text-[#0a0a0a] px-8 py-4 rounded-md font-medium hover:bg-[#128C7E] transition-colors inline-flex items-center"
          >
            <i className="whatsapp-icon"></i>
            Chamar no WhatsApp
          </a>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;

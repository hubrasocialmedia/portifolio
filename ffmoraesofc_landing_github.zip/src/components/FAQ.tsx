import { useState, useEffect } from 'react';

const FAQ = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState<number | null>(null);

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('faq');
      if (element) {
        const position = element.getBoundingClientRect();
        if (position.top < window.innerHeight * 0.75) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check on initial load
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleAccordion = (index: number) => {
    setActiveIndex(activeIndex === index ? null : index);
  };

  const faqs = [
    {
      question: "Por que é importante ter presença digital?",
      answer: "A presença digital é essencial hoje porque 97% dos consumidores pesquisam online antes de comprar. Sem uma estratégia digital eficaz, você está perdendo clientes para a concorrência. Uma presença digital bem estruturada aumenta sua visibilidade, credibilidade e facilita a conexão com seu público-alvo."
    },
    {
      question: "Como o tráfego pago pode beneficiar minha marca?",
      answer: "O tráfego pago permite direcionar sua mensagem exatamente para quem tem interesse no seu produto ou serviço. Com estratégias bem definidas, você consegue aumentar a visibilidade da sua marca rapidamente, gerar leads qualificados e aumentar suas conversões, com um ROI mensurável e otimizável continuamente."
    },
    {
      question: "Qual o prazo para começar a ver resultados?",
      answer: "Os primeiros resultados começam a aparecer entre 30 e 90 dias, dependendo do seu segmento e da competitividade do mercado. Estratégias de tráfego pago podem gerar resultados mais rápidos, enquanto SEO e marketing de conteúdo são investimentos de médio a longo prazo que trazem resultados mais sustentáveis."
    },
    {
      question: "Como posso cancelar caso não esteja satisfeito?",
      answer: "Trabalhamos sem contratos longos e inflexíveis. Você pode cancelar a qualquer momento com um aviso prévio de 30 dias. Nossa prioridade é sua satisfação e resultados, por isso oferecemos essa flexibilidade. No entanto, a maioria dos nossos clientes permanece conosco por anos devido aos resultados consistentes."
    },
    {
      question: "Quais métricas vocês utilizam para medir resultados?",
      answer: "Utilizamos métricas alinhadas aos seus objetivos de negócio, como tráfego qualificado, taxa de conversão, custo por aquisição, ROI, engajamento nas redes sociais e posicionamento orgânico. Fornecemos relatórios mensais detalhados e transparentes para que você acompanhe o progresso da sua estratégia digital."
    }
  ];

  return (
    <section id="faq" className="py-20 bg-[#0f1a20]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ainda ficou com <span className="text-[#00e5ff]">alguma dúvida?</span>
          </h2>
          <p className="text-gray-300 max-w-3xl mx-auto">
            Confira as perguntas mais frequentes feitas por nossos clientes. Se sua dúvida não estiver aqui, entre em contato diretamente.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className={`mb-4 border-b border-gray-800 pb-4 ${
                isVisible 
                  ? 'opacity-100 translate-y-0' 
                  : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 100}ms`, transitionDuration: '800ms', transitionProperty: 'all' }}
            >
              <button
                className="flex justify-between items-center w-full text-left focus:outline-none"
                onClick={() => toggleAccordion(index)}
              >
                <h3 className="text-lg font-medium">• {faq.question}</h3>
                <svg
                  className={`w-6 h-6 text-[#00e5ff] transform ${activeIndex === index ? 'rotate-180' : ''} transition-transform`}
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
              
              <div 
                className={`mt-2 text-gray-400 overflow-hidden transition-all duration-300 ${
                  activeIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}
              >
                <p className="pb-2">{faq.answer}</p>
              </div>
            </div>
          ))}
        </div>

        <div className={`mt-12 text-center ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'} transition-all duration-500 delay-500`}>
          <a 
            href="#contato" 
            className="bg-[#4ade80] text-[#0a0a0a] px-6 py-3 rounded-md font-medium hover:bg-[#3fcb6e] transition-colors inline-block"
          >
            Falar com um especialista
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQ;

import { useEffect } from 'react';
import './Navbar.css';
import logoHubra from '../assets/images/LogoHubra.png';

const Navbar = () => {
  useEffect(() => {
    const handleScroll = () => {
      const navbar = document.querySelector('.navbar');
      if (navbar) {
        if (window.scrollY > 50) {
          navbar.classList.add('navbar-scrolled');
        } else {
          navbar.classList.remove('navbar-scrolled');
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <a href="#home" className="navbar-logo">
          <img src={logoHubra} alt="Hubra" />
        </a>
        
        <div className="navbar-links">
          <a href="#home">Início</a>
          <a href="#servicos">Serviços</a>
          <a href="#sobre">Sobre</a>
          <a href="#resultados">Resultados</a>
          <a href="https://wa.me/+5533991372932" className="navbar-cta">Falar Agora</a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;

import { useState, useEffect } from 'react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const element = document.getElementById('sobre');
      if (element) {
        const position = element.getBoundingClientRect();
        if (position.top < window.innerHeight * 0.75) {
          setIsVisible(true);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Check on initial load
    
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section id="sobre" className="py-20 bg-[#0f1a20]">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col lg:flex-row items-center gap-12">
          {/* Imagem removida conforme solicitado */}
          
          {/* Right side - Content */}
          <div className={`w-full ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-10'} transition-all duration-1000 delay-300`}>
            <div className="inline-block px-4 py-1 bg-[#00e5ff]/10 rounded-full text-[#00e5ff] text-sm font-medium mb-4">
              SOBRE NÓS
            </div>
            
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              O QUE A <span className="text-[#00e5ff]">HUBRA</span> FAZ?
            </h2>
            
            <p className="text-gray-300 mb-6">
              A marca Hubra surgiu na pandemia com a ideia de uma loja de dropshipping. Em 2024, renasceu com foco total, ajudando empresas a crescer com visibilidade e resultados reais.
            </p>
            
            <p className="text-gray-300 mb-8">
              Especialista em marketing, social media e design, com 5 anos de experiência. Após atuar no mercado CLT, migrei para o empreendedorismo para oferecer soluções estratégicas que unem criatividade e resultado.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#00e5ff] flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#0a0a0a]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-300">Criação de sites e landing pages de alta conversão</span>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#00e5ff] flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#0a0a0a]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-300">Gestão de redes sociais com estratégia personalizada</span>
              </div>
              
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 rounded-full bg-[#00e5ff] flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-[#0a0a0a]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <span className="text-gray-300">Campanhas de tráfego pago com alto ROI</span>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <a 
                href="#contato" 
                className="bg-[#00e5ff] text-[#0a0a0a] px-6 py-3 rounded-md font-medium hover:bg-[#00c2d8] transition-colors"
              >
                Falar Agora
              </a>
              
              <a 
                href="#servicos" 
                className="text-[#00e5ff] hover:text-[#00c2d8] transition-colors flex items-center gap-2"
              >
                <span>Ver Serviços</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;

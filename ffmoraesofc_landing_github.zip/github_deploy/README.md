# Landing Page Profissional - @ffmoraesofc

Este repositório contém o código-fonte da landing page profissional para @ffmoraesofc, desenvolvida com React, TypeScript e TailwindCSS.

![Preview da Landing Page](/screenshots/preview.png)

## 🚀 Características

- Design moderno com efeitos de vidro e gradientes
- Animação de abertura com logo
- Layout totalmente responsivo
- Integração com WhatsApp
- Seções completas: Sobre, Serviços, Resultados, Depoimentos, FAQ e Contato
- Otimizado para SEO

## 📋 Pré-requisitos

Para executar este projeto localmente, você precisará ter instalado:

- [Node.js](https://nodejs.org/) (v16 ou superior)
- [npm](https://www.npmjs.com/) (v8 ou superior) ou [yarn](https://yarnpkg.com/) (v1.22 ou superior)

## 🔧 Instalação

1. Clone este repositório:
```bash
git clone https://github.com/seu-usuario/ffmoraesofc-landing.git
cd ffmoraesofc-landing
```

2. Instale as dependências:
```bash
npm install
# ou
yarn install
```

3. Execute o projeto em modo de desenvolvimento:
```bash
npm run dev
# ou
yarn dev
```

4. Acesse `http://localhost:5173` no seu navegador para ver o site em execução.

## 🛠️ Construído com

- [React](https://reactjs.org/) - Biblioteca JavaScript para construção de interfaces
- [TypeScript](https://www.typescriptlang.org/) - Superset tipado de JavaScript
- [Vite](https://vitejs.dev/) - Ferramenta de build rápida
- [TailwindCSS](https://tailwindcss.com/) - Framework CSS utilitário

## 📦 Implantação

Para gerar os arquivos de produção:

```bash
npm run build
# ou
yarn build
```

Os arquivos serão gerados na pasta `dist`, que pode ser implantada em qualquer serviço de hospedagem estática como:

- [GitHub Pages](https://pages.github.com/)
- [Netlify](https://www.netlify.com/)
- [Vercel](https://vercel.com/)
- [Cloudflare Pages](https://pages.cloudflare.com/)

### Implantação no GitHub Pages

1. Crie um repositório no GitHub
2. Adicione o repositório remoto:
```bash
git remote add origin https://github.com/seu-usuario/ffmoraesofc-landing.git
```

3. Instale o pacote gh-pages:
```bash
npm install --save-dev gh-pages
# ou
yarn add --dev gh-pages
```

4. Adicione os seguintes scripts ao seu `package.json`:
```json
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}
```

5. Adicione a propriedade `base` ao seu arquivo `vite.config.ts`:
```typescript
export default defineConfig({
  base: '/ffmoraesofc-landing/',
  // outras configurações...
})
```

6. Execute o comando de deploy:
```bash
npm run deploy
# ou
yarn deploy
```

7. Acesse `https://seu-usuario.github.io/ffmoraesofc-landing/`

## ⚙️ Personalização

### Alterando o número do WhatsApp

Para alterar o número do WhatsApp, edite os seguintes arquivos:

1. `src/App.tsx` - Linha com `href="https://wa.me/+5533991372932"`
2. `src/components/Contact.tsx` - Linha com `href="https://wa.me/+5533991372932"` e texto do número
3. `src/components/Footer.tsx` - Linha com `href="https://wa.me/+5533991372932"`

### Alterando as imagens e logos

As imagens e logos estão localizadas na pasta `src/assets/images/`. Substitua os arquivos mantendo os mesmos nomes ou atualize as referências no código.

## 📄 Licença

Este projeto está sob a licença MIT - veja o arquivo [LICENSE.md](LICENSE.md) para detalhes.

## 📱 Contato

Para qualquer dúvida ou sugestão, entre em contato pelo WhatsApp: [+5533991372932](https://wa.me/+5533991372932)
